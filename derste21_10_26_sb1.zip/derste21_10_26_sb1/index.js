const express=require("express");
const app=express();
const {logData}=require("./model/log.js")
const path=require("path");
app.set("view engine","ejs")
const adminrouter=require("./router/adminrouter");
const userrouter=require("./router/userrouter");

app.use("/static",express.static(path.join(__dirname,"public")));

//-----loglama middleware
app.use((req,res,next)=>{
   //console.log("loglama arka planda yapıldı");
   logrecord={
            url:req.url,
            date:new Date().toLocaleDateString(),
            time:new Date().toLocaleTimeString()
        }
    logData.push(logrecord);
    next();
})

// //yetkilendirme middleware
// app.use((req,res,next)=>{
//     const isAuth=false; //db ile karşılaştırma sonucu
//     if (!isAuth) res.send("Yetkisiz erişim");
//     else next();

// });

app.use("/admin",adminrouter);
app.use("/user",userrouter);

//middleware. Yukarıdakilerin hiç biri çalışmazsa bu çalışır.
app.use((req,res,next)=>{
  //res.status(404).send("Sayfa bulunamadı!!!!");
  next("Sayfa bulunamadı!!!!");
});

app.use((err,req,res,next)=>{
   res.status(400).send("Hata:"+err);
});

app.listen(3000,()=>{
    console.log("Sunucu çalıştı");
});
