const {logData}=require("../model/log.js")

exports.adduser=(req,res)=>{
    res.send(req.url+" isteği işlendi");
}

exports.getuser=(req,res)=>{
    //res.send(req.url+" isteği işlendi");
    console.log(__dirname);
    //res.sendFile(path.join(__dirname,"views/admin/getuser.html"));
    userdata={
        ad:"Merve",
        soyad:"Taşkın"
    }
    res.render("admin/getuser.ejs",{userdata});
}

exports.listuser=(req,res)=>{
  const userlist=[
    {name:"Merve", surname:"Taşkın"},
    {name:"Sıla", surname:"Çördük"},
    {name:"Kurtuluş", surname:"Yüksel"}
  ];

  res.render("admin/listuser.ejs",{userlist});
}

exports.getuseridli=(req,res)=>{
    res.send("Aradığınız User Id="+req.params.id);
}

exports.getlog=(req,res)=>{
    //res.send(logData);
    res.render("admin/log1.ejs",{logData})
}