exports.homepage=(req,res)=>{
    res.send("User ana sayfa");
}

exports.getblog=(req,res)=>{
    //res.send(req.url+" isteği işlendi");
    console.log(__dirname);
    //res.sendFile(path.join(__dirname,"views/admin/getuser.html"));
    userdata={
        ad:"C#",
        soyad:"deneme falan filan"
    }
    res.render("user/getblog.ejs",{userdata});
}

