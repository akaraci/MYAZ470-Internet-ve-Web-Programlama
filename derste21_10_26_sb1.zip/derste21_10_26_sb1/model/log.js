// export const logData=[{
//     url:NaN,
//     date:NaN,
//     time:NaN
// }];

//import {logData} from "./data/log.js" bu şekilde import edebilirsiniz.


//------------------
// const logData=[{
//     url:NaN,
//     date:NaN,
//     time:NaN
// }];

// export default logData;

//-------------------
//Yukarıdaki gibi tanımlnırsa süslü parantez kullanmadan aşağıdaki gibi import edilebilir.
//Ancak sadece bir tane default tanımlanır
//import logDataaaa from "./data/log.js"

const logData=[{
    url:NaN,
    date:NaN,
    time:NaN
}];

module.exports = {logData}