//authourize yapılıyor. Her istek için çalışır.
exports.isAuth=(req,res,next) => {
    const authController=false;
    if (authController) next();
    else res.send("Yetkisiz erişim")
}