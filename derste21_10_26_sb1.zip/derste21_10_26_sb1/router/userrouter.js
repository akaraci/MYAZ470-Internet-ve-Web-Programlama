const express=require("express")
const router= express.Router()

const userController=require("../controller/usercontroller.js")

router.get("/",userController.homepage);

router.get("/getblog",userController.getblog);

module.exports = router;