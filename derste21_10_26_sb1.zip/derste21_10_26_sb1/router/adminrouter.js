const express=require("express")
const router= express.Router()

const adminController=require("../controller/admincontroller.js")

const {isAuth}=require("../middleware/authourize.js")

router.get("/adduser",isAuth,adminController.adduser);

router.get("/getuser",isAuth,adminController.getuser);

router.get("/listuser",isAuth,adminController.listuser);

router.get("/getuser/:id",isAuth,adminController.getuseridli)

router.get("/getlog",adminController.getlog)

module.exports = router;