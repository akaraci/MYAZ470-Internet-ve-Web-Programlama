const express=require("express");
const adminController=require("../controller/admin");
router=express.Router();

router.get("/",adminController.homePage);

router.get("/list/anc",adminController.listAnc);
module.exports = router;