const data=require("../model/data");

exports.homePage=(req,res,next)=>{
    res.render("admin/index",{contentTitle:"Ana Sayfa",pageTitle:"Home Page"});
}

exports.listAnc=(req,res,next)=>{
    res.render("admin/list-anc",{contentTitle:"Duyuru Listeleme",pageTitle:"List Anouncment",data:data});
}