const express=require("express");
const path = require('path');

const app=express();

//set view engine
app.set('view engine', 'ejs');

//---Static
app.use('/static', express.static(path.join(__dirname, 'public')));
app.use(express.static(path.join(__dirname,"node_modules")))

//Router 
const adminRouter=require("./routes/admin");
app.use("/admin",adminRouter);

app.listen(3000,()=>{
    console.log("Server running");
});