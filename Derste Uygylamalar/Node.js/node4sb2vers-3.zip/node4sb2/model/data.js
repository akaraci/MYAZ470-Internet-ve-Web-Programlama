const data=[
    {
        noticeid:100,
        title:"Vize Tarihleri",
        explain:"Vize Tarihleri Açıklandı",
        isActive:false      
    },
    {
        noticeid:200,
        title:"Final Tarihleri",
        explain:"Final Tarihleri Açıklandı",
        isActive:true      
    }
]

module.exports=data;