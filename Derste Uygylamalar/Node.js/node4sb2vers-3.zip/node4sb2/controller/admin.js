const data=require("../model/data");

exports.homePage=(req,res,next)=>{
    res.render("admin/index",{contentTitle:"Admin Ana Sayfa",pageTitle:"Admin Home Page"});
}

exports.listAnc=(req,res,next)=>{

    res.render("admin/list-anc",{contentTitle:"Duyuru Liste",pageTitle:"List Anaouncment",data:data});

}