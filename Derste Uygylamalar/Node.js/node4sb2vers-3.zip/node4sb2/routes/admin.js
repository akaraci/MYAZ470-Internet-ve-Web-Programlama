const adminController=require("../controller/admin")
const express=require("express");

router=express.Router();

router.get("/",adminController.homePage);

router.get("/list/anc",adminController.listAnc);

module.exports = router;