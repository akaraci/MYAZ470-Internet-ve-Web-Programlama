const express=require("express");
const path = require('path');
const bodyParser = require('body-parser')
const configSession=require("./middleware/config_Session");
const cookieParser = require('cookie-parser')

const app=express();

//set view engine
app.set('view engine', 'ejs');

//body parser. Bodyden gelen bilgileri backend'de almak için tanımlanması zorunludur.
app.use(bodyParser.urlencoded({ extended: true })); //extend:true->enabled json

//midleware session
app.use(configSession);
app.use(cookieParser());

//---Static
app.use('/static', express.static(path.join(__dirname, 'public')));
app.use(express.static(path.join(__dirname,"node_modules")))

//router
const adminRouter=require("./routes/admin");
const authRouter=require("./routes/auth");
app.use("/admin", adminRouter);
app.use("/auth", authRouter);

app.listen(3000,()=>{
  console.log("server running");
});