const adminController=require("../controller/admin")
const express=require("express");
const isAuth=require("../middleware/isAuth");

router=express.Router();

router.get("/",adminController.homePage);

router.get("/list/anc",isAuth,adminController.listAnc);

router.get("/delete/anc/:id",isAuth,adminController.get_deleteAnc);

router.post("/delete/anc",isAuth,adminController.post_deleteAnc);

router.get("/add/anc",isAuth,adminController.get_addAnc);

router.post("/add/anc",isAuth,adminController.post_addAnc);

router.get("/edit/anc/:id",isAuth,adminController.get_editAnc)

router.post("/edit/anc/:id",isAuth,adminController.post_editAnc)

module.exports = router;