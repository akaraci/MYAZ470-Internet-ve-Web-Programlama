const session = require("express-session");
const authData=require("../model/authdata");
const bcrypt = require('bcrypt');

exports.getLogin=(req,res,next)=>{  
    const email=req.cookies.email;
    const password=req.cookies.password;
    
    res.render("auth/login",{
                                    pageTitle:"Login",
                                    contentTitle:"Login",
                                    authInfo:{email:email,password:password}
                                });
}

exports.postLogin=async(req,res,next)=>{
    const user=authData.find(x=>x.email==req.body.email);
    if (user==undefined) {
        return res.redirect("login");
    }
    if (await bcrypt.compare(req.body.password,user.password)){ //şifre uyuşuyorsa
        req.session.isAuth=1;
        req.session.fullname=user.name;

        if (req.body.cbhatirla=="1"){ 
            res.cookie("email",req.body.email);
            res.cookie("password",req.body.password);
        }
        else{
            res.clearCookie("email");
            res.clearCookie("password"); 
        }
    
        const url=req.query.url || "/admin/list/anc"; //req.query.url varsa onu yoksa "/admin/list/anc" url olarak kabul et.
        return res.redirect(url);
    }
    //şifre uyuşmuyorsa
    //req.session.message={text:"Şifre hatalı",class:"warning"};
    res.redirect("login");
}

exports.signOut=async(req,res,next)=>{
    await req.session.destroy(); //session temizle
    res.redirect("/auth/login"); //ana sayfaya git
}
