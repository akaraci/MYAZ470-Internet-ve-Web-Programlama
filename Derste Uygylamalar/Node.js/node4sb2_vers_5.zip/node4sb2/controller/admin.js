const data=require("../model/data");
const dialog = require('dialog-node');
const notifier=require("../messagebox/notifier")

exports.homePage=(req,res,next)=>{
    res.render("admin/index",{contentTitle:"Admin Ana Sayfa",pageTitle:"Admin Home Page"});
}

exports.listAnc=(req,res,next)=>{

    res.render("admin/list-anc",{contentTitle:"Duyuru Liste",pageTitle:"List Anaouncment",data:data});

}

exports.get_deleteAnc=(req,res,next)=>{
    const id=req.params.id;
    const deldataIndex=data.findIndex(x=>x.noticeid==id);
    data.splice(deldataIndex,1);
    res.redirect("/admin/list/anc");
}

exports.post_deleteAnc=(req,res,next)=>{
    const id=req.body.ancid;
    console.log("Ancid=",id);
    const deldataIndex=data.findIndex(x=>x.noticeid==id);
    data.splice(deldataIndex,1);
    res.redirect("/admin/list/anc");
}

exports.get_addAnc=(req,res,next)=>{
    res.render("admin/add-anc",{contentTitle:"Duyuru Ekle",pageTitle:"Add Anaouncment"});
}

exports.post_addAnc=(req,res,next)=>{
    const body=req.body;
    // console.log(body);
    const newdata={
        noticeid:data.length+1,
        title:body.title,
        explain:body.explain,
        isActive:body.isActive?true:false
    } 
    data.push(newdata);
    //res.redirect("/admin/list/anc");
    // dialog.warn("Kaydınız gerçekleşti", "Bilgi", 0, ()=>{
    //     res.redirect("/admin/list/anc");
    // });

    notifier("Bilgi","Kaydınız gerçekleşti",()=>{
        res.redirect("/admin/list/anc");
    })

}

exports.get_editAnc=(req,res,next)=>{
    //console.log(req.params.id);
    const oldData=data.find(x=>x.noticeid==req.params.id);
    //console.log(oldData);
    res.render("admin/edit-anc",{pageTitle:"Duyuru Düzeltme",
                                contentTitle:"Edit Anouncment",
                                data:oldData
                            });
}

exports.post_editAnc=(req,res,next)=>{
    console.log(req.body.noticeid);
    newdata={
        noticeid:req.body.id,  //req.params.id, 
        title:req.body.title, 
        explain:req.body.explain,
        isActive:req.body.isActive?true:false
    }
    const index=data.findIndex(x=>x.noticeid==req.params.id);
    data[index]=newdata;
    res.redirect("/admin/list/anc");
}