const dialogNode=require("../messagebox/dialognode");

const data=require("../model/data");

exports.homePage=(req,res,next)=>{
    res.render("admin/index",{contentTitle:"Ana Sayfa",pageTitle:"Home Page"});
}

exports.listAnc=(req,res,next)=>{
    res.render("admin/list-anc",{contentTitle:"Duyuru Listeleme",pageTitle:"List Anouncment",data:data});
}

exports.get_deleteAnc=(req,res,next)=>{
    const deldataIndex=data.findIndex(x=>x.noticeid==req.params.id);
    //console.log("delete anc=",deldataIndex);
    data.splice(deldataIndex,1); //başlangıç ve adet parametreleri
    res.redirect("/admin/list/anc");
}

exports.post_deleteAnc=(req,res,next)=>{
    console.log(req.body);  
    const deldataIndex=data.findIndex(x=>x.noticeid==req.body.ancid);
    //console.log("delete anc=",deldataIndex);
    data.splice(deldataIndex,1); //başlangıç ve adet parametreleri
    res.redirect("/admin/list/anc");
}

exports.get_addAnc=(req,res,next)=>{
    res.render("admin/add-anc",{contentTitle:"Duyuru Ekle",pageTitle:"Add Anouncment Page"});
}

exports.post_addAnc=(req,res,next)=>{
    const body=req.body;
    console.log("Type=",typeof body,body);
    console.log(body.title);
    const newdata={
        noticeid:data.length+1,
        title:body.title,
        explain:body.explain,
        isActive:body.isActive?true:false
    }
    data.push(newdata);
    //res.redirect("/admin/list/anc");

  //notifier("Bilgi","Kayıt eklendi",()=>{res.redirect("/admin/list/anc");})
dialogNode("Bilgi","Kayıt Eklendi",()=>{res.redirect("/admin/list/anc")});
    
}