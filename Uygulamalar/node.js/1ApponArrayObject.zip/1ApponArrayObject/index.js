const data=require("./data/dataarray");
const express=require("express");
const path = require('path')
const bodyParser = require('body-parser')//post edilen verileri almak için kullanılır.
//const session = require('express-session'); //sadece import etmek yeterli değil. middleware klasörü içinde tanımlı config 'de kullanılmalıdır.
const configSession=require("./middleware/config_Session");
const cookieParser = require('cookie-parser'); //Beni hatırla özelliği için cookie kullanılmalıdır.
const csurf=require("csurf"); //csrf dolandırılcığını önlemek için kullanılır
const locals=require("./middleware/locals");


const app=express();

//set view engine
app.set('view engine', 'ejs');

//---Static
app.use('/static', express.static(path.join(__dirname, 'public')));
app.use(express.static(path.join(__dirname,"node_modules")))

//middleware
//Gelen verilerin sadece string olarak ele alnıması istenirse, extended: false özelliği kullanılır, 
//fakat eğer bir JSON nesnesi olarak ele alınması istenirse, extended: true parametresi ile kullanmak gerekir.
app.use(bodyParser.urlencoded({ extended: true }));
app.use(configSession);
app.use(cookieParser());

//hangi bir form get edildiğinde csrfToken bilgisi gelir. Bu bilgi ejs dosyasına gönderilmeli ve form içinde post edilmelidir.
app.use(csurf()); //session middleware'inden sonra olması önemlidir.

app.use(locals); //local değerlerin tanımlandığı middleware. Tüm ejs dosyalarından erişilir. Böylece her controller'dan parametre olarak gönderilmeye gerek kalmaz.
// app.use((req,res,next)=>{
//     req.session.isAuth=1;
//     next();
// });
//---routes
const adminRouter=require("./routes/admin");
const userRouter=require("./routes/user");
const authRouter=require("./routes/auth");
app.use("/admin",adminRouter);
app.use("/user",userRouter);
app.use("/auth",authRouter);


//error catch for express
app.use((err,req,res,next)=>{
    res.status(400).send(err);
    console.log("err=",err);

});

app.use("*",(req,res)=>{ //* yukarıdakilerin hiç biri gerçekleşme çalıştır demektir.
    res.status(404).send("Sayfa Yok");
   });

app.listen(3000,()=>{
    console.log("Server running");
})


