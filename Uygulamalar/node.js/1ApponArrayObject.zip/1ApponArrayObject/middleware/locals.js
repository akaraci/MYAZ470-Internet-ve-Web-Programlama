module.exports=(req,res,next)=>{
    res.locals.fullname=req.session.fullname;
    next();
}