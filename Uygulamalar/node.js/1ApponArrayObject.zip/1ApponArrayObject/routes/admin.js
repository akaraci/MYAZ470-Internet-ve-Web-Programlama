const express=require("express");
const adminController=require("../controller/admin");
const isAuth=require("../middleware/isAuth");

const csrf=require("../middleware/csrf"); 

router=express.Router();

router.get("/",isAuth,adminController.homePage);

router.get("/add/anc",isAuth,csrf,adminController.get_addAnc); //csrfToken local olarak tanımlanıyor.

router.post("/add/anc",isAuth,adminController.post_addAnc);

router.get("/list/anc",isAuth,csrf,adminController.listAnc); //delete işlemi list üzerinden gerçekleştirildiğinde list işleminde csrfToken elde edilmelidir.

router.get("/edit/anc/:id",isAuth,csrf,adminController.get_editAnc);

router.post("/edit/anc/:id",isAuth,adminController.post_editAnc);

router.get("/delete/anc/:id",isAuth,adminController.get_deleteAnc);

router.post("/delete/anc",isAuth,adminController.post_deleteAnc);

router.get("/ckeditor",adminController.ckeditor)

module.exports=router;