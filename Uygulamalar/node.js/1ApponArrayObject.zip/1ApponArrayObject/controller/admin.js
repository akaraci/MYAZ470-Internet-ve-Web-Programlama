const data=require("../data/dataarray");
const notifier=require("../messagebox/notifier"); //bildirim alanından mesaj
const dialogNode=require("../messagebox/dialognode");



exports.homePage=(req,res,next)=>{
    // res.send("Ana Sayfa");
    res.render("admin/index",{title:"Ana sayfa",contentTitle:"Admin Home Page"});
}

exports.get_addAnc=(req,res,next)=>{
    // res.status(200).send("Duyuru Ekleme");
    res.render("admin/add-anc",{
                                title:"Duyuru Ekle",
                                contentTitle:"Add Anouncment Page"
                                
                            });
}

exports.post_addAnc=(req,res,next)=>{
    const body=req.body;
    console.log("Type=",typeof body,body);
    console.log(body.title);
    const newdata={
        noticeid:data.length+1,
        title:body.title,
        explain:body.explain,
        isActive:body.isActive?true:false
    }
    data.push(newdata);
    //notifier("Bilgi","Kayıt eklendi",()=>{res.redirect("/admin/list/anc");})
dialogNode("Bilgi","Kayıt Eklendi",()=>{res.redirect("/admin/list/anc")});
    
}

exports.listAnc=(req,res,next)=>{
    res.render("admin/list-anc",{title:"Duyuru Listele",contentTitle:"List Anouncment",data:data});
}

exports.get_editAnc=(req,res,next)=>{
    console.log(req.params.id);
    const oldData=data.find(x=>x.noticeid==req.params.id);
    console.log(oldData);
    res.render("admin/edit-anc",{
                                title:"Duyuru Düzeltme",
                                contentTitle:"Edit Anouncment",
                                data:oldData//,
                                //csrfToken:req.csrfToken()
                            });
}

exports.post_editAnc=(req,res,next)=>{
    console.log(req.body.noticeid);
    newdata={
        noticeid:req.body.noticeid,
        title:req.body.title, 
        explain:req.body.explain,
        isActive:req.body.isActive?true:false
    }
    console.log(newdata);
    const index=data.findIndex(x=>x.noticeid==req.params.id);
    console.log(data[index]);
    data[index]=newdata;

    res.redirect("/admin/list/anc");
    // console.log(oldData);
    // res.render("admin/edit-anc",{title:"Duyuru Düzeltme",contentTitle:"Edit Anouncment",data:oldData});
}

//Bu silme işlemi için birinci yöntem. ModalBox içine bir link buton yerleştirdik ve bu butona
// link olarak /delete/anc/:id route'ını yerleştirdik ve silme işlemini get route ile gerçekleştiridk.
//Ancak aşağıdaki ikinci yöntem daha güvenlidir.
exports.get_deleteAnc=(req,res,next)=>{
    const deldataIndex=data.findIndex(x=>x.noticeid==req.params.id);
    console.log("delete anc=",deldataIndex);
    data.splice(deldataIndex,1); //başlangıç ve adet parametreleri
    res.redirect("/admin/list/anc");
}

//Silme işlemini iki şekilde yaptık
//Modalbox içine form yerleştirerek post işlemi gerçekleştirdik ve hidden input içine yerleştirdiğimiz 
//Id ile silme işlemini yaptık
exports.post_deleteAnc=(req,res,next)=>{
    console.log(req.body.ancid);  
    const deldataIndex=data.findIndex(x=>x.noticeid==req.body.ancid);
    console.log("delete anc=",deldataIndex);
    data.splice(deldataIndex,1);//başlangıç ve adet parametreleri
    res.redirect("/admin/list/anc");
}

exports.ckeditor=(req,res,next)=>{
 res.render("admin/ckeditorexample");
}