const data=require("../data/dataarray");

exports.userHome=(req,res,next)=>{
    res.render("user/index",{title:"Ana sayfa",contentTitle:"Ana sayfa",data:data});
}

exports.viewAnc=(req,res,next)=>{
    viewData=data.find(x=>x.noticeid==req.params.id)
    console.log(viewData);
    res.render("user/view-anc",{title:viewData.title,contentTitle:viewData.title,viewData:viewData,data:data});
}
