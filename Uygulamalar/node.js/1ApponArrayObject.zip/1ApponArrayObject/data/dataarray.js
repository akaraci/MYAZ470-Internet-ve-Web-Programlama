const data=[
    {
        noticeid:1,
        title:"Vize Tarihleri",
        explain:"Vize Tarihleri Açıklandı",
        isActive:false      
    },
    {
        noticeid:2,
        title:"Final Tarihleri",
        explain:"Final Tarihleri Açıklandı",
        isActive:true      
    }
]

module.exports=data;