const express=require("express");
const app=express();
const {logData}=require("./data/log.js")
const path=require("path");
//-----loglama middleware
app.use((req,res,next)=>{
   //console.log("loglama arka planda yapıldı");
   logrecord={
            url:req.url,
            date:new Date().toLocaleDateString(),
            time:new Date().toLocaleTimeString()
        }
    logData.push(logrecord);
    next();
})

//yetkilendirme middleware
app.use((req,res,next)=>{
    const isAuth=true; //db ile karşılaştırma sonucu
    if (!isAuth) res.send("Yetkisiz erişim");
    else next();

});

app.get("/admin/adduser",(req,res)=>{
    res.send(req.url+" isteği işlendi");
});

app.get("/admin/getuser",(req,res)=>{
    //res.send(req.url+" isteği işlendi");
    console.log(__dirname);
    res.sendFile(path.join(__dirname,"views/getuser.html"));
});

app.get("/admin/getuser/:id",(req,res)=>{
    res.send("Aradığınız User Id="+req.params.id);
})

app.get("/admin/getlog",(req,res)=>{
    res.send(logData);
})

app.listen(3000,()=>{
    console.log("Sunucu çalıştı");
});
